
/**
 *  Create an 'ActiveTextFieldDemo' class.
 *
 *            div - The 'id' of the target 'div' in which display the component
 *      textField - A newly instance subclass of ActiveTextField
 */

ActiveTextFieldDemo = Core.extend(Echo.Application, {
                
    $construct : function(div, textField) {
    
        Echo.Application.call(this);

        var client = new Echo.FreeClient(this, document.getElementById(div));
        
        // Define the package 'ActiveTextField' in order to load ActiveTextField icons
        client.addResourcePath("ActiveTextField", "resource/");
        
        client.init();
        this.rootComponent.add(textField);
    }
});

