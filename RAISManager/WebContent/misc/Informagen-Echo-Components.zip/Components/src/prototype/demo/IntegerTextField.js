
window.onload = function() {

Core.Web.init();

// Default Integer Textfield
new ActiveTextFieldDemo("demo0", new Informagen.IntegerTextField());

// Using setters
new ActiveTextFieldDemo("demo1", new Informagen.IntegerTextField({
                emptyIcon: "leftArrow",
              invalidIcon: "warning",
             validMessage: "You qualify for AARP!",
           invalidMessage: "Sorry, you are too young.",
             minimumValue: 50,
             maximumValue: 99,
   invalidForegroundColor: "#ff0000",
   invalidBackgroundColor: "#ffff99"
}));

            
new ActiveTextFieldDemo("demo2", new Informagen.IntegerTextField({
           emptyIcon: "leftArrow",
           validIcon: "good",
         invalidIcon: "warning",
     messagePosition: "top",
        iconPosition: "default",
             message: "Enter your Age:",
        minimumValue: 21,
        maximumValue: 99
}));

new ActiveTextFieldDemo("demo3", new Informagen.IntegerTextField({
        iconPosition: "leading",
     messagePosition: "top",
             message: "Age:",
           emptyIcon: "rightArrow",
           validIcon: "empty",
         invalidIcon: "rightArrow",
       minimumValue:   1,
        maximumValue: 99
}));

new ActiveTextFieldDemo("demo4", new Informagen.IntegerTextField({
        iconPosition: "leading",
     messagePosition: "top",
             message: "A Number, 1 to 100",
           emptyIcon: "rightArrow",
           validIcon: "empty",
         invalidIcon: "rightArrow",
        minimumValue: 1,
        maximumValue: 100
}));

};
