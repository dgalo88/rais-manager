package org.informagen.echo.webcontainer;

import org.informagen.echo.app.SimpleCaptcha;


import nextapp.echo.app.Component;
import nextapp.echo.app.util.Context;
import nextapp.echo.app.update.ClientUpdateManager;

import nextapp.echo.webcontainer.AbstractComponentSynchronizePeer;
import nextapp.echo.webcontainer.ContentType;
import nextapp.echo.webcontainer.ResourceRegistry;
import nextapp.echo.webcontainer.Service;
import nextapp.echo.webcontainer.ServerMessage;
import nextapp.echo.webcontainer.WebContainerServlet;
import nextapp.echo.webcontainer.service.JavaScriptService;



public class SimpleCaptchaPeer extends AbstractComponentSynchronizePeer {

    private static final String REGISTRY_KEY = "Informagen.SimpleCaptcha";

    private static final String JAVASCRIPT_PATH = "org/informagen/echo/resource/SimpleCaptcha.js";
    private static final String CANVAS_TEXT_JAVASCRIPT_PATH = "org/informagen/echo/resource/canvastext.js";

    static {
        
        String[] javaScriptPaths = new String[] { JAVASCRIPT_PATH, CANVAS_TEXT_JAVASCRIPT_PATH };
        Service service = JavaScriptService.forResources(REGISTRY_KEY, javaScriptPaths);

        WebContainerServlet.getServiceRegistry().add(service);
 
        // Add the 'SimpleCaptcha' images to the resource registry
        ResourceRegistry resources = WebContainerServlet.getResourceRegistry();        
        resources.addPackage("SimpleCAPTCHA", "org/informagen/echo/resource/captcha/");
        
        // Image are named 'n.jpg', where n varies from 1 to 191
        for(int i=1; i<=191; i++)
            resources.add("SimpleCAPTCHA", Integer.toString(i) + ".jpg", ContentType.IMAGE_JPEG);
   }



    public SimpleCaptchaPeer() {
        super();
        addOutputProperty(SimpleCaptcha.PROPERTY_STRING);
    }

    // Intialize and invoke superclass initialization -------------------------------------

    public void init(Context context, Component component) {
        super.init(context, component);
        ServerMessage serverMessage = (ServerMessage) context.get(ServerMessage.class);
        serverMessage.addLibrary(REGISTRY_KEY);
    }

     // Abstract methods from 'ComponentSynchronizePeer' -----------------------------------
    //  Return application class and registry unique name
    
   public Class getComponentClass() {
        return SimpleCaptcha.class;
    }

    public String getClientComponentType(boolean shortType) {
        return REGISTRY_KEY;
    }

    //-------------------------------------------------------------------------------------
    // Override the following three methods in order to work with local component properties
    //
    //  - getOutputProperty - used when sending property changes to the JavaScript client
    //  - getInputPropertyClass
    //  - storeInputProperty

    public Object getOutputProperty(Context context, Component component,
                                    String propertyName, int propertyIndex) {
                        
        if (SimpleCaptcha.PROPERTY_STRING.equals(propertyName)) 
            return ((SimpleCaptcha)component).getString();
        
        return super.getOutputProperty(context, component, propertyName, propertyIndex);
    }

    public Class getInputPropertyClass(String propertyName) {
                
        if (SimpleCaptcha.PROPERTY_STRING.equals(propertyName)) 
            return String.class;
        
        return super.getInputPropertyClass(propertyName);
    }


    public void storeInputProperty(Context context, Component component,
                                   String propertyName, int propertyIndex, Object newValue) {

        ClientUpdateManager clientUpdateManager = (ClientUpdateManager) context.get(ClientUpdateManager.class);
                              
        if (SimpleCaptcha.PROPERTY_STRING.equals(propertyName)) 
            clientUpdateManager.setComponentProperty(component, SimpleCaptcha.PROPERTY_STRING, newValue);
    }


}