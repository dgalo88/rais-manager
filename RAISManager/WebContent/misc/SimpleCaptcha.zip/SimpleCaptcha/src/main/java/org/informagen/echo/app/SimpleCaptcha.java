package org.informagen.echo.app;

import nextapp.echo.app.Component;
import nextapp.echo.app.Border;
import nextapp.echo.app.Color;
import nextapp.echo.app.Extent;

import java.util.Random;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** 
 * <code>SimpleCaptcha</code> implements a CAPTCHA.
 *
 *  For browsers which support the 'canvas' tag, an image is generated, otherwise
 *    a pre-build JPEG image is used.
 *
 *  When the fallback method of using a JPEG is used these CAPTCHA should not 
 *    be considered very secure.
 *  
 */

public class SimpleCaptcha extends Component  {
    
    // Style properties
    public static final String PROPERTY_HEIGHT = "height";
    public static final String PROPERTY_WIDTH  = "width";

    // Non-style properties
    public static final String PROPERTY_USE_IMAGES = "useImages";
    public static final String PROPERTY_STRING = "string";

    private String string = null;

    public SimpleCaptcha() {
        this("echo");
    }

    public SimpleCaptcha(String initialValue) {
        setString(initialValue);
    }

    /**
     * Sets the height of the CAPTCHA image
     * This property only supports <code>Extent</code>s with
     * fixed (i.e., not percent) units.
     * 
     * @param newValue the new height
     */
    public void setHeight(Extent newValue) {
        set(PROPERTY_HEIGHT, newValue);
    }


    /**
     * Returns the height of the CAPTCHA image
     * This property only supports <code>Extent</code>s with
     * fixed (i.e., not percent) units.
     * 
     * @return the height
     */
    public Extent getHeight() {
        return (Extent) get(PROPERTY_HEIGHT);
    }
  
         
    /**
     * Sets the width of theCAPTCHA image
     * This property supports <code>Extent</code>s with
     * either fixed or percentage-based units.
     * 
     * @param newValue the new width
     */
    public void setWidth(Extent newValue) {
        set(PROPERTY_WIDTH, newValue);
    }
    
    
    /**
     * Returns the width of the CAPTCHA image
     * This property supports <code>Extent</code>s with
     * either fixed or percentage-based units.
     * 
     * @return the width
     */
    public Extent getWidth() {
        return (Extent) get(PROPERTY_WIDTH);
    }
         
    public void setUseImages(boolean useImages) {        
        set(PROPERTY_USE_IMAGES, (useImages ? Boolean.TRUE : Boolean.FALSE));
    }
    
    
    public boolean getUseImages() {
        Boolean value = (Boolean) get(PROPERTY_USE_IMAGES);
        
        return (value == null) ? false : value.booleanValue();
    }


    public String getString() {
        return string;
    }

    public void nextString() {
        int index = new Random().nextInt(190) + 1;
        setString(samples[index]);
    }

    public void setString(String string) {
        String oldValue = this.string;
        this.string = string;
        firePropertyChange(PROPERTY_STRING, oldValue, string);
     }


    public void processInput(String inputName, Object inputValue) {
        super.processInput(inputName, inputValue);
        
        if (PROPERTY_STRING.equals(inputName))
            setString((String) inputValue);
    }

    static final String[] samples = {
              "polish", "past", "part",   "when,","much", "seed", "soap","glove","sticky","soap",
              "profit", "bent", "collar","where","weight","again","weight","boat","small","profit",
              "sound","chin","flag","body","salt","birth","crime","false","sleep","square",
              "canvas","mine","safe","mark","degree","bell","color","expert","rule","parcel",
              "degree","waste","after","army","moon","brain","news","silver","rain","stiff",
              "horse","smile","shirt","this","grip","sharp","knot","neck","woman","smell",
              "round","linen","same","right","adjust","jewel","bell","pocket","green","mother",
              "mine","rice","loss","tail","foot","porter","spring","desire","screw","spade",
              "bent","letter","glass","sugar","fear","every","muscle","right","rate","butter",
              "sail","summer","snake","wheel","sheep","glove","poison","tooth","bucket","wood",
              "great","school","sudden","wind","step","credit","pain","design","front","push",
              "seem","cord","sound","scale","with","wind","cloth","screw","garden","west",
              "judge","goat","animal","warm","join","turn","school","white","keep","basin",
              "tooth","face","range","tight","nail","seem","female","public","potato","idea",
              "snake","flower","narrow","still","hope","glass","lock","hand","face","fear",
              "copper","debt","shoe","paint","butter","roll","blood","story","doubt","meat",
              "offer","clean","memory","like","wrong","jump","amount","regret","free","crush",
              "pull","dress","door","male","black","please","flag","fact","nose","taste",
              "snake","cold","attack","crush","canvas","shame","book","wound","nation","fire",
              "good"};



}